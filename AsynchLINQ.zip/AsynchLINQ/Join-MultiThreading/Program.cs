﻿
using System;

namespace HelloWorld
{
    class Program
    {

        static void Test1()
        {
            Console.WriteLine("Test1 Started");
            for (int i = 0; i <= 5; i++)
            
                Console.WriteLine("Test1 Executing " + i);
                Console.WriteLine("Test1 Exiting");
                ///   Thread.Sleep(5000); //Sleep is used to pause a thread and 5000 is MilliSeconds that means 5 Seconds    
            
        }
        static void Test2()
        {
            Console.WriteLine("Test2 Started");
            for (int i = 0; i <= 5; i++)
           
                Console.WriteLine("Test2 Executing " + i);
                Console.WriteLine("Test2 Exiting");
                 Thread.Sleep(5000);
           
        }

        static void Test3()
        {
            Console.WriteLine("Test3 Started");
            for (int i = 0; i <= 5; i++)
           
                Console.WriteLine("Test3 Executing " + i);
                Console.WriteLine("Test3 Exiting");
                /// Thread.Sleep(5000);
            
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Main Thread Started");
            Thread ThreadObject1 = new Thread(Test1); //Creating the Thread    
            Thread ThreadObject2 = new Thread(Test2);
            Thread ThreadObject3 = new Thread(Test3);
            ThreadObject1.Start(); //Starting the Thread    
            ThreadObject2.Start();
            ThreadObject3.Start();

            ThreadObject1.Join(3000); //Starting the Thread    
            ThreadObject2.Join();
            ThreadObject3.Join();
            Console.WriteLine("Main Thread Exited");
            Console.ReadLine();
        }
    }
}