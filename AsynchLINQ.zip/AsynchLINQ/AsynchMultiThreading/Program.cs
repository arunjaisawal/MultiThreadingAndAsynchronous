﻿//class Program
//{
//    static async Task Main(string[] args)
//    {
//        // await callMethod();
//        //Task task = new Task(CallMethod);
//        //task.Start();
//        //task.Wait();

//        var count = await Method1();
//        var getcount = await Method3(count);
//        Console.WriteLine(getcount);

//        Console.ReadKey();

//    }

//    static async void CallMethod()
//    {
//        var count = await Method1();
//        var getcount = await Method3(count);
//        Console.WriteLine(getcount);

//    }



//    public static async Task<int> Method1()
//    {
//        int count = 0;
//        await Task.Run(() =>
//        {
//            for (int i = 0; i < 10; i++)
//            {
//                Console.WriteLine(" Method 1");
//                count += 1;
//                // Thread.Sleep(2000);
//                //Task.Delay(100).Wait();
//                //Task.Delay(3000).Wait();
//            }
//        });
//        return count;
//    }


//    public static async Task<int> Method3(int count)

//    {
//        int countdata = 0;
//        await Task.Run(() =>
//        {
//            for (int i = 0; i < 5; i++)
//            {
//                Console.WriteLine(" Method 3");
//                countdata += 1;
//                //Thread.Sleep(2000);
//            }
//        });
//        return countdata;
//    }
//}




class Program
{
    static void Main(string[] args)
    {
        Method1();
        Method2();
        Console.ReadKey();
    }

    public static async Task Method1()
    {
        await Task.Run(() =>
        {
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine(" Method 1");
                // Do something
                Task.Delay(100).Wait();
            }
        });
    }


    public static void Method2()
    {
        for (int i = 0; i < 5; i++)
        {
            Console.WriteLine(" Method 2");
            // Do something
            Task.Delay(100).Wait();
        }
    }
}