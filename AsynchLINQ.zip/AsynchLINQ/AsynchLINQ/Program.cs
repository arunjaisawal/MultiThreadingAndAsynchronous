﻿
using System;

namespace HelloWorld
{
    class Program
    {

        static void Example1()
        {
            Console.WriteLine("Thread1 Started");
            for (int i = 0; i <= 5; i++)
            {
                Console.WriteLine("Thread1 Executing");
                Thread.Sleep(5000); //Sleep is used to pause a thread and 5000 is MilliSeconds that means 5 Seconds    
            }
        }
        static void Example2()
        {
            Console.WriteLine("Thread2 Started");
            for (int i = 0; i <= 5; i++)
            {
                Console.WriteLine("Thread2 Executing");
                Thread.Sleep(5000);
            }
        }
        //static void WorkerThread()
        //{
        //    Console.WriteLine("2. WorkerThread Started");
        //    for (int i = 0; i <= 3; i++)
        //    {
        //        Console.WriteLine("-> WorkerThread Executing");
        //        Console.WriteLine("Child Thread Paused");
        //        //Sleep method is used to pause the Thread for a specific period    
        //        Thread.Sleep(3000);
        //        Console.WriteLine("Child Thread Resumed");
        //    }
        //}


        //public void Display()
        //{
        //    //Lock is used to lock-in the Current Thread    
        //    lock (this)
        //    {
        //        for (int i = 0; i <= 3; i++)
        //        {
        //            Thread.Sleep(3000);
        //            Console.WriteLine($ "My Name is Abhishek{i}");
        //        }
        //    }
        //}


        static void Main(string[] args)
        {
            ////Exmaple Take: 
            //Console.WriteLine("***************  Start: Take Example   ***************** ");
            //int[] num = { 5, 4, 2, 1, 5, 6, 7 };
            //var first3Numbersw = num.Take(3);
            //foreach( var n in first3Numbersw)
            //{
            //    Console.WriteLine(n);
            //}
            //Console.WriteLine("***************    End: Take Example   ***************** ");

            ////Exmaple Take While: 
            //Console.WriteLine("***************  Start: Take While Example   ***************** ");
            //int[] num1 = { 5, 4, 2, 1, 3, 6, 7 };
            //var first3Numberslessthe6 = num.TakeWhile(n=>n<6);
            //foreach (var n in first3Numberslessthe6)
            //{
            //    Console.WriteLine(n);
            //}
            //Console.WriteLine("***************    End: Take While Example   ***************** ");

            ////Exmaple Sequence Equals: 
            //Console.WriteLine("***************  Start: Sequence Equals Example   ***************** ");
            //var wordsA = new string[] { "cherry", "appple", "blue" };
            //var wordsB = new string[] { "cherry", "appple", "blue" };

            //bool match = wordsA.SequenceEqual(wordsB);
            //Console.WriteLine($"The sequyences match:{match}");
            //Console.WriteLine("***************    End: Sequence Equals Example   ***************** ");



            ////Exmaple ZIP: 
            //Console.WriteLine("***************  Start: ZIP Example   ***************** ");
            //var vaectorA = new int[] {0,2,4,5,6 };
            //var vaectorB = new int[] {1,3,5,7,8};

            //int dotProduct = vaectorA.Zip(vaectorB,(a,b)=>a*b).Sum();
            //Console.WriteLine($"Dot Product:{dotProduct}");
            //Console.WriteLine("***************    End: ZIP Example   ***************** ");


            ///****///
            //      ////Exmaple
            Thread ThreadObject1 = new Thread(Example1); //Creating the Thread    
            Thread ThreadObject2 = new Thread(Example2);
            ThreadObject1.Start(); //Starting the Thread    
            ThreadObject2.Start();




            //////Exmaple
            ////Creating the WorkerThread with the help of Thread class.    
            //Thread ThreadObject1 = new Thread(WorkerThread);
            //ThreadObject1.Start(); //Starting the Thread    
            //                   ThreadObject1.Join(); //Using Join to block the current Thread    
            //Console.WriteLine("1. MainThread Started");
            //for (int i = 0; i <= 3; i++)
            //{
            //    Console.WriteLine("-> MainThread Executing");
            //    Thread.Sleep(3000); //Here 5000 is 5000 Milli Seconds means 5 Seconds    
            //}
            //// We are calling the Name of Current running Thread using CurrentThread    
            //Thread Th = Thread.CurrentThread;
            //Th.Name = "Main Thread";
            //Console.WriteLine("\nGetting the Name of Currently running Thread");
            ////Name Property is used to get the name of the current Thread    
            //Console.WriteLine($"Current Thread Name is: {Th.Name}");
            ////Priority Property is used to display the Priority of current Thread    
            //Console.WriteLine($"Current Thread Priority is: {Th.Priority}");


            //Creating object for LockExample1 Class as _locker so that we can access its Display Method    
            //Program _locker = new Program();
            //Console.WriteLine("Threading with the help of Lock");
            ////Calling the Display Method using ThreadStart Delegate which is supplied to Thread constructor.    
            //Thread t1 = new Thread(new ThreadStart(_locker.Display));
            //Thread t2 = new Thread(new ThreadStart(_locker.Display));
            //t1.Start(); //Starting Thread1    
            //t2.Start(); //Starting Thread2
            //

            Console.ReadLine();
        }
    }
}