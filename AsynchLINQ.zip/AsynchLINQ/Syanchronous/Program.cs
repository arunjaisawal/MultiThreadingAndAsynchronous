﻿
class Program
{
    static void Main(string[] args)
    {
        // await callMethod();

        var count =  Method1();
        var getcount =  Method3(count);
        Console.WriteLine(getcount);

        Console.ReadKey();

    }


    public static int Method1()
    {
        int count = 0;
       
            for (int i = 0; i < 100; i++)
            {
                Console.WriteLine(" Method 1");
                count += 1;
                Thread.Sleep(2000);
            }
      
        return count;
    }


    public static int Method3(int count)
    {
        int countdata = 0;
        
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine(" Method 3");
                countdata += 1;
            }
        
        return countdata;
    }
}