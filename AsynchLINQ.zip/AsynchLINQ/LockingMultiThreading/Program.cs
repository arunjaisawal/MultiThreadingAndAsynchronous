﻿
using System;

namespace HelloWorld
{
    class Program
    {

        public void Example()
        {
            lock (this) { 
            Console.WriteLine("[Csharp is");
            Thread.Sleep(3000);
            Console.WriteLine("Object Oriented Language]");

            }
        }
      
        static void Main(string[] args)
        {
            Program obj = new Program();
            Thread ThreadObject1 = new Thread(obj.Example); //Creating the Thread    
            Thread ThreadObject2 = new Thread(obj.Example);
            Thread ThreadObject3 = new Thread(obj.Example);
            ThreadObject1.Start(); //Starting the Thread    
            ThreadObject2.Start();
            ThreadObject3.Start();

            
           /// Console.WriteLine("Main Thread Exited");
            Console.ReadLine();
        }
    }
}